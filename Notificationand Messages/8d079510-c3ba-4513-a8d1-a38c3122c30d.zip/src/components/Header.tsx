import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BellIcon, MessageCircleIcon, SearchIcon, UserIcon, ChevronDownIcon } from 'lucide-react';
const Header: React.FC = () => {
  const location = useLocation();
  const [showNotifications, setShowNotifications] = useState(false);
  const isActive = (path: string) => {
    return location.pathname === path ? 'border-b-2 border-blue-500' : '';
  };
  return <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center space-x-6">
            <Link to="/" className="text-blue-600 text-xl font-semibold">
              Direct Connect
            </Link>
            <nav className="hidden md:flex space-x-1">
              <Link to="/find-jobs" className={`px-3 py-2 text-gray-600 hover:text-blue-600 ${isActive('/find-jobs')}`}>
                Find Jobs
              </Link>
              <Link to="/my-projects" className={`px-3 py-2 text-gray-600 hover:text-blue-600 ${isActive('/my-projects')}`}>
                My Projects
              </Link>
              <Link to="/proposals" className={`px-3 py-2 text-gray-600 hover:text-blue-600 ${isActive('/proposals')}`}>
                Proposals
              </Link>
              <Link to="/community" className={`px-3 py-2 text-gray-600 hover:text-blue-600 ${isActive('/community')}`}>
                Community
              </Link>
              <Link to="/mentorship" className={`px-3 py-2 text-gray-600 hover:text-blue-600 ${isActive('/mentorship')}`}>
                Mentorship
              </Link>
              <Link to="/messages" className={`px-3 py-2 text-gray-600 hover:text-blue-600 ${isActive('/messages') || isActive('/')}`}>
                Message
              </Link>
              <Link to="/earnings" className={`px-3 py-2 text-gray-600 hover:text-blue-600 ${isActive('/earnings')}`}>
                Earnings
              </Link>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative hidden md:block">
              <input type="text" placeholder="Search for jobs..." className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 w-64" />
              <SearchIcon className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <div className="relative">
              <Link to="/messages" className="relative p-2 text-gray-600 hover:text-blue-600 rounded-full hover:bg-gray-100">
                <MessageCircleIcon className="h-6 w-6" />
                <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  2
                </span>
              </Link>
            </div>
            <div className="relative">
              <Link to="/notifications" className="relative p-2 text-gray-600 hover:text-blue-600 rounded-full hover:bg-gray-100">
                <BellIcon className="h-6 w-6" />
                <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  5
                </span>
              </Link>
            </div>
            <div className="flex items-center space-x-2 border-l pl-4 ml-2">
              <div className="h-8 w-8 bg-gray-300 rounded-full flex items-center justify-center">
                <UserIcon className="h-5 w-5 text-gray-600" />
              </div>
              <span className="hidden md:inline text-gray-700">Samarth</span>
              <ChevronDownIcon className="h-4 w-4 text-gray-500" />
            </div>
          </div>
        </div>
      </div>
    </header>;
};
export default Header;