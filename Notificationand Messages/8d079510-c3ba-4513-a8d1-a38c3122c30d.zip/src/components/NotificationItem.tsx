import React from 'react';
import { Link } from 'react-router-dom';
import { MessageCircleIcon, FileTextIcon, BriefcaseIcon, DollarSignIcon, BellIcon, CheckIcon, TrashIcon, MoreVerticalIcon } from 'lucide-react';
interface Notification {
  id: number;
  type: 'message' | 'proposal' | 'job' | 'payment' | 'system';
  content: string;
  time: string;
  read: boolean;
  avatar: string;
  link: string;
}
interface NotificationItemProps {
  notification: Notification;
}
const NotificationItem: React.FC<NotificationItemProps> = ({
  notification
}) => {
  const getIcon = () => {
    switch (notification.type) {
      case 'message':
        return <MessageCircleIcon className="h-5 w-5 text-blue-600" />;
      case 'proposal':
        return <FileTextIcon className="h-5 w-5 text-green-600" />;
      case 'job':
        return <BriefcaseIcon className="h-5 w-5 text-purple-600" />;
      case 'payment':
        return <DollarSignIcon className="h-5 w-5 text-yellow-600" />;
      case 'system':
        return <BellIcon className="h-5 w-5 text-gray-600" />;
    }
  };
  return <div className={`p-4 hover:bg-gray-50 ${!notification.read ? 'bg-blue-50' : ''}`}>
      <div className="flex items-start">
        <div className="flex-shrink-0 mr-3">
          {notification.avatar ? <img src={notification.avatar} alt="User avatar" className="h-10 w-10 rounded-full object-cover" /> : <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
              {getIcon()}
            </div>}
        </div>
        <div className="flex-grow min-w-0">
          <Link to={notification.link} className="block">
            <p className={`text-sm text-gray-900 ${!notification.read ? 'font-medium' : ''}`}>
              {notification.content}
            </p>
            <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
          </Link>
        </div>
        <div className="ml-3 flex items-center">
          <button className="p-1.5 text-gray-400 hover:text-blue-600 rounded-full hover:bg-gray-100" title="Mark as read">
            <CheckIcon className="h-4 w-4" />
          </button>
          <button className="p-1.5 text-gray-400 hover:text-red-600 rounded-full hover:bg-gray-100" title="Delete">
            <TrashIcon className="h-4 w-4" />
          </button>
          <button className="p-1.5 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100" title="More options">
            <MoreVerticalIcon className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>;
};
export default NotificationItem;