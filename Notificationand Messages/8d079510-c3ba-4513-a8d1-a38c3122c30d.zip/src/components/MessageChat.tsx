import React, { useState } from 'react';
import { PaperclipIcon, SmileIcon, SendIcon, PhoneIcon, VideoIcon, MoreHorizontalIcon } from 'lucide-react';
interface Conversation {
  id: number;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unread: boolean;
  online: boolean;
}
interface Message {
  id: number;
  sender: 'me' | 'them';
  text: string;
  time: string;
}
interface MessageChatProps {
  conversation: Conversation;
  messages: Message[];
}
const MessageChat: React.FC<MessageChatProps> = ({
  conversation,
  messages
}) => {
  const [newMessage, setNewMessage] = useState('');
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      // In a real app, you'd send the message to an API
      console.log('Sending message:', newMessage);
      setNewMessage('');
    }
  };
  return <div className="flex-grow flex flex-col">
      {/* Chat header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center">
          <div className="relative mr-3">
            <img src={conversation.avatar} alt={conversation.name} className="h-10 w-10 rounded-full object-cover" />
            {conversation.online && <span className="absolute bottom-0 right-0 h-2.5 w-2.5 bg-green-500 rounded-full border-2 border-white"></span>}
          </div>
          <div>
            <h3 className="font-medium text-gray-900">{conversation.name}</h3>
            <p className="text-xs text-gray-500">
              {conversation.online ? 'Online' : 'Offline'}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button className="p-2 text-gray-600 hover:text-blue-600 hover:bg-gray-100 rounded-full">
            <PhoneIcon className="h-5 w-5" />
          </button>
          <button className="p-2 text-gray-600 hover:text-blue-600 hover:bg-gray-100 rounded-full">
            <VideoIcon className="h-5 w-5" />
          </button>
          <button className="p-2 text-gray-600 hover:text-blue-600 hover:bg-gray-100 rounded-full">
            <MoreHorizontalIcon className="h-5 w-5" />
          </button>
        </div>
      </div>
      {/* Chat messages */}
      <div className="flex-grow p-4 overflow-y-auto bg-gray-50">
        <div className="space-y-4">
          {messages.map(message => <div key={message.id} className={`flex ${message.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-lg ${message.sender === 'me' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-white border border-gray-200 rounded-bl-none'}`}>
                <p>{message.text}</p>
                <p className={`text-xs mt-1 text-right ${message.sender === 'me' ? 'text-blue-200' : 'text-gray-500'}`}>
                  {message.time}
                </p>
              </div>
            </div>)}
        </div>
      </div>
      {/* Message input */}
      <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-200 bg-white">
        <div className="flex items-center">
          <button type="button" className="p-2 text-gray-500 hover:text-blue-600">
            <PaperclipIcon className="h-5 w-5" />
          </button>
          <input type="text" value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Type a message..." className="flex-grow mx-2 py-2 px-4 border border-gray-300 rounded-full focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500" />
          <button type="button" className="p-2 text-gray-500 hover:text-blue-600">
            <SmileIcon className="h-5 w-5" />
          </button>
          <button type="submit" disabled={!newMessage.trim()} className={`ml-2 p-2 rounded-full ${newMessage.trim() ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}>
            <SendIcon className="h-5 w-5" />
          </button>
        </div>
      </form>
    </div>;
};
export default MessageChat;