import React from 'react';
import { SearchIcon, PlusIcon } from 'lucide-react';
interface Conversation {
  id: number;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unread: boolean;
  online: boolean;
}
interface MessageSidebarProps {
  conversations: Conversation[];
  selectedId: number;
  onSelect: (id: number) => void;
}
const MessageSidebar: React.FC<MessageSidebarProps> = ({
  conversations,
  selectedId,
  onSelect
}) => {
  return <div className="w-full md:w-80 border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-800">Messages</h2>
          <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-full">
            <PlusIcon className="h-5 w-5" />
          </button>
        </div>
        <div className="relative">
          <input type="text" placeholder="Search conversations..." className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500" />
          <SearchIcon className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
      </div>
      <div className="overflow-y-auto flex-grow">
        {conversations.map(conversation => <div key={conversation.id} className={`flex items-center p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${selectedId === conversation.id ? 'bg-blue-50' : ''}`} onClick={() => onSelect(conversation.id)}>
            <div className="relative mr-3">
              <img src={conversation.avatar} alt={conversation.name} className="h-12 w-12 rounded-full object-cover" />
              {conversation.online && <span className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-white"></span>}
            </div>
            <div className="flex-grow min-w-0">
              <div className="flex justify-between items-center mb-1">
                <h3 className="font-medium text-gray-900 truncate">
                  {conversation.name}
                </h3>
                <span className="text-xs text-gray-500">
                  {conversation.time}
                </span>
              </div>
              <p className={`text-sm truncate ${conversation.unread ? 'font-medium text-gray-900' : 'text-gray-500'}`}>
                {conversation.lastMessage}
              </p>
            </div>
            {conversation.unread && <span className="ml-2 h-2 w-2 bg-blue-600 rounded-full"></span>}
          </div>)}
      </div>
    </div>;
};
export default MessageSidebar;