import React, { useState } from 'react';
import { BellIcon, CheckIcon, TrashIcon, FilterIcon } from 'lucide-react';
import NotificationItem from '../components/NotificationItem';
const NotificationsPage: React.FC = () => {
  const [filter, setFilter] = useState('all');
  // Sample notification data
  const notifications = [{
    id: 1,
    type: 'message',
    content: 'Alex Johnson sent you a new message',
    time: '10 minutes ago',
    read: false,
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
    link: '/messages'
  }, {
    id: 2,
    type: 'proposal',
    content: 'Your proposal for "React Developer for E-commerce Website" was viewed by the client',
    time: '2 hours ago',
    read: false,
    avatar: '',
    link: '/proposals'
  }, {
    id: 3,
    type: 'job',
    content: 'New job matching your skills: "Frontend Developer for SaaS Product"',
    time: '3 hours ago',
    read: true,
    avatar: '',
    link: '/find-jobs'
  }, {
    id: 4,
    type: 'payment',
    content: 'Payment of $850 for "UI Design Project" has been processed',
    time: '1 day ago',
    read: true,
    avatar: '',
    link: '/earnings'
  }, {
    id: 5,
    type: 'message',
    content: 'Sarah Williams mentioned you in a conversation',
    time: '1 day ago',
    read: true,
    avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
    link: '/messages'
  }, {
    id: 6,
    type: 'system',
    content: 'Your account verification is complete. You now have full access to Direct Connect features.',
    time: '2 days ago',
    read: true,
    avatar: '',
    link: '/profile'
  }, {
    id: 7,
    type: 'proposal',
    content: 'Client has accepted your proposal for "UX/UI Designer for Mobile App"',
    time: '3 days ago',
    read: true,
    avatar: '',
    link: '/proposals'
  }];
  const filteredNotifications = filter === 'all' ? notifications : filter === 'unread' ? notifications.filter(n => !n.read) : notifications.filter(n => n.type === filter);
  const unreadCount = notifications.filter(n => !n.read).length;
  return <div className="max-w-3xl mx-auto bg-white rounded-lg shadow overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-gray-800 flex items-center">
            <BellIcon className="h-6 w-6 mr-2 text-blue-600" />
            Notifications
            {unreadCount > 0 && <span className="ml-2 bg-blue-600 text-white text-xs rounded-full px-2 py-0.5">
                {unreadCount} new
              </span>}
          </h1>
          <div className="flex space-x-2">
            <button className="p-2 text-gray-600 hover:text-blue-600 hover:bg-gray-100 rounded-full" title="Mark all as read">
              <CheckIcon className="h-5 w-5" />
            </button>
            <button className="p-2 text-gray-600 hover:text-red-600 hover:bg-gray-100 rounded-full" title="Clear all notifications">
              <TrashIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
        <div className="flex overflow-x-auto pb-3 mb-2">
          <button onClick={() => setFilter('all')} className={`px-4 py-2 mr-2 rounded-full text-sm whitespace-nowrap ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
            All
          </button>
          <button onClick={() => setFilter('unread')} className={`px-4 py-2 mr-2 rounded-full text-sm whitespace-nowrap ${filter === 'unread' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
            Unread
          </button>
          <button onClick={() => setFilter('message')} className={`px-4 py-2 mr-2 rounded-full text-sm whitespace-nowrap ${filter === 'message' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
            Messages
          </button>
          <button onClick={() => setFilter('proposal')} className={`px-4 py-2 mr-2 rounded-full text-sm whitespace-nowrap ${filter === 'proposal' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
            Proposals
          </button>
          <button onClick={() => setFilter('job')} className={`px-4 py-2 mr-2 rounded-full text-sm whitespace-nowrap ${filter === 'job' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
            Jobs
          </button>
          <button onClick={() => setFilter('payment')} className={`px-4 py-2 mr-2 rounded-full text-sm whitespace-nowrap ${filter === 'payment' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
            Payments
          </button>
          <button onClick={() => setFilter('system')} className={`px-4 py-2 mr-2 rounded-full text-sm whitespace-nowrap ${filter === 'system' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
            System
          </button>
        </div>
      </div>
      <div className="divide-y divide-gray-100">
        {filteredNotifications.length > 0 ? filteredNotifications.map(notification => <NotificationItem key={notification.id} notification={notification} />) : <div className="p-8 text-center text-gray-500">
            <BellIcon className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium mb-2">No notifications</h3>
            <p>
              You don't have any {filter !== 'all' ? filter : ''} notifications
              at the moment.
            </p>
          </div>}
      </div>
    </div>;
};
export default NotificationsPage;