import React, { useState } from 'react';
import { SearchIcon, PaperclipIcon, SmileIcon, SendIcon, PhoneIcon, VideoIcon, MoreHorizontalIcon } from 'lucide-react';
import MessageSidebar from '../components/MessageSidebar';
import MessageChat from '../components/MessageChat';
const MessagesPage: React.FC = () => {
  const [selectedConversation, setSelectedConversation] = useState(0);
  // Sample data for conversations
  const conversations = [{
    id: 0,
    name: 'Alex Johnson',
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
    lastMessage: "I'll send over the project brief today",
    time: '10:23 AM',
    unread: true,
    online: true
  }, {
    id: 1,
    name: 'Sarah Williams',
    avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
    lastMessage: "Let me know when you're available for a call",
    time: 'Yesterday',
    unread: false,
    online: false
  }, {
    id: 2,
    name: 'Michael Chen',
    avatar: 'https://randomuser.me/api/portraits/men/22.jpg',
    lastMessage: 'The designs look great! Just a few tweaks needed',
    time: 'Yesterday',
    unread: true,
    online: true
  }, {
    id: 3,
    name: 'Emma Davis',
    avatar: 'https://randomuser.me/api/portraits/women/29.jpg',
    lastMessage: 'Contract is ready for your review',
    time: 'Mon',
    unread: false,
    online: false
  }, {
    id: 4,
    name: 'James Wilson',
    avatar: 'https://randomuser.me/api/portraits/men/46.jpg',
    lastMessage: 'Thanks for the quick response!',
    time: 'Sun',
    unread: false,
    online: true
  }];
  // Sample messages for the selected conversation
  const messages = [{
    id: 1,
    sender: 'them',
    text: "Hi there! I saw your profile and I'm interested in discussing a potential project.",
    time: '10:03 AM'
  }, {
    id: 2,
    sender: 'me',
    text: "Hello! Thanks for reaching out. I'd be happy to discuss the project. What did you have in mind?",
    time: '10:05 AM'
  }, {
    id: 3,
    sender: 'them',
    text: "We're looking for someone to help us redesign our company website. It's a full revamp with new branding guidelines.",
    time: '10:10 AM'
  }, {
    id: 4,
    sender: 'them',
    text: 'The project would last about 6-8 weeks. Are you available during that timeframe?',
    time: '10:11 AM'
  }, {
    id: 5,
    sender: 'me',
    text: 'That sounds interesting! Yes, I should be available. Could you share more details about the scope and your expectations?',
    time: '10:15 AM'
  }, {
    id: 6,
    sender: 'them',
    text: "Great! I'll send over the project brief today with all the details including the budget and timeline.",
    time: '10:23 AM'
  }];
  return <div className="flex h-[calc(100vh-80px)] bg-white rounded-lg shadow overflow-hidden">
      <MessageSidebar conversations={conversations} selectedId={selectedConversation} onSelect={setSelectedConversation} />
      <MessageChat conversation={conversations[selectedConversation]} messages={messages} />
    </div>;
};
export default MessagesPage;