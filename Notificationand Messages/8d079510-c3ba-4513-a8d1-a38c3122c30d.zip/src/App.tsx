import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import MessagesPage from './pages/MessagesPage';
import NotificationsPage from './pages/NotificationsPage';
export function App() {
  return <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<MessagesPage />} />
          <Route path="/messages" element={<MessagesPage />} />
          <Route path="/notifications" element={<NotificationsPage />} />
        </Routes>
      </Layout>
    </Router>;
}